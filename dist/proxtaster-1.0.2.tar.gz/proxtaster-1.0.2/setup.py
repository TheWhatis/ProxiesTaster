"""Скрипт для установлки пакета"""
from setuptools import setup


name = 'proxtaster'
version = '1.0.2'


# Long description
with open('README.md', 'r') as readme:
    long_description = readme.read()

url = 'https://gitlab.com/thewhatis/ptaster'


if __name__ == '__main__':
    setup(
        name=name,
        version=version,

        author='Whatis',
        author_email='asdwdagwahwabe@gmail.com',

        description='Пакет для проверки прокси',

        long_description=long_description,
        long_description_content_type='text/markdown',

        license='GPL',
        platforms='any',

        url=url,
        download_url=f"{url}/dist/{name}-{version}.zip",

        packages=['ptaster'],
        include_package_data=True,
        install_requires=[
            'aiohttp',
            'aiohttp-proxy',
            'fake-useragent',
            'PyEventEmitter'
        ]
    )
