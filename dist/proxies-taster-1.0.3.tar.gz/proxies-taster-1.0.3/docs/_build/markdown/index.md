<!-- ProxiesTaster documentation master file, created by
sphinx-quickstart on Sun Oct  8 21:36:51 2023.
You can adapt this file completely to your liking, but it should at least
contain the root `toctree` directive. -->

# ProxiesTaster документация!

**Предисловие**

«Пакет», «Package» - пакет для pypi,
для подключения уже к вашим скриптам
для проверки прокси

«Приложение», «App» - скрипт, консольное
приложение для проверки прокси `proxies-taster`,
которое включает в себя пакет ProxiesTaster

То-есть при установке пакета через pip, пакет
не будет включать в себя скрипт `proxies-taster`
и зависимости для него

# Contents:

* [App](app.md)
* [Package](package.md)
  * [ProxiesTaster](package/ProxiesTaster.md)
  * [Types](package/types.md)
  * [Events](package/events_data.md)

# Indices and tables

* [Алфавитный указатель](genindex.md)
* [Состав модуля](py-modindex.md)
* [Поиск](search.md)
